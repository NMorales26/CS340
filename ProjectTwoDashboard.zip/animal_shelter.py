from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self):
        """
        Initializes the MongoDB connection using the provided credentials.
        """
        USER = 'aacuser'
        PASS = 'newyork26'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32957
        DB = 'AAC'
        COL = 'animals'
        
        # Initialize MongoDB connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """
        Insert a document into the animals collection.
        
        :param data: A dictionary representing the animal document to insert.
        :return: True if the insert was successful, otherwise False.
        """
        if data:
            try:
                self.collection.insert_one(data)  # Insert data into the collection
                return True
            except Exception as e:
                print(f"Error inserting document: {e}")
                return False
        else:
            raise ValueError("Data parameter cannot be empty.")

    def read(self, query):
        """
        Query documents from the animals collection.
        
        :param query: A dictionary representing the query filter.
        :return: A list of documents matching the query, or an empty list if no documents are found.
        """
        try:
            return list(self.collection.find(query))  # Fetch documents using find() method
        except Exception as e:
            print(f"Error querying documents: {e}")
            return []

    def update(self, query, data):
        """
        Update documents in the animals collection.

        :param query: A dictionary representing the query to find the document to update.
        :param data: A dictionary representing the new data to update.
        :return: True if the update was successful, otherwise False.
        """
        if query and data:
            try:
                result = self.collection.update_one(query, {"$set": data})
                return result.modified_count > 0
            except Exception as e:
                print(f"Error updating document: {e}")
                return False
        else:
            raise ValueError("Query and data parameters cannot be empty.")

    def delete(self, query):
        """
        Delete documents from the animals collection.

        :param query: A dictionary representing the query filter for documents to delete.
        :return: True if the delete was successful, otherwise False.
        """
        if query:
            try:
                result = self.collection.delete_one(query)
                return result.deleted_count > 0
            except Exception as e:
                print(f"Error deleting document: {e}")
                return False
        else:
            raise ValueError("Query parameter cannot be empty.")


